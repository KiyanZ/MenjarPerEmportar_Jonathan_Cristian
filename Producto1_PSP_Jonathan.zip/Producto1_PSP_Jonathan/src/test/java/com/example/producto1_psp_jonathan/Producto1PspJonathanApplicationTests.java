package com.example.producto1_psp_jonathan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Producto1PspJonathanApplicationTests {

    @Test
    void contextLoads() {
    }

}
