package com.example.producto1_psp_jonathan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Producto1PspJonathanApplication {

    public static void main(String[] args) {
        SpringApplication.run(Producto1PspJonathanApplication.class, args);
    }

}
